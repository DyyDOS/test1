import React from 'react';
import {
  EuiPage,
  EuiPageHeader,
  EuiTitle,
  EuiPageBody,
  EuiPageContent,
  EuiPageContentHeader,
  EuiPageContentBody,
  EuiText
} from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';

export class Main extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    /*
       FOR EXAMPLE PURPOSES ONLY.  There are much better ways to
       manage state and update your UI than this.
    */
    const { httpClient } = this.props;
    httpClient.get('../api/Forensic/example').then((resp) => {
      this.setState({ time: resp.data.time });
    });
  }
  render() {
    const { title } = this.props;
    return (
      <EuiPage>
        <EuiPageBody>
          <EuiPageHeader>
            <EuiTitle size="l">
              <h2>
                <FormattedMessage
                  id="forensic.helloWorldText"
                  defaultMessage="Mô hình hóa cảnh báo nguy hiểm theo địa chỉ IP"
                  values={{ title }}
                />
              </h2>
            </EuiTitle>
          </EuiPageHeader>
          <EuiPageContent>
            <EuiPageContentHeader>
              <EuiTitle>
              <iframe src="http://192.168.1.73:5601/app/kibana#/visualize/edit/412045f0-9b04-11ea-b049-dbe23a527da9?embed=true&_g=(filters%3A!()%2CrefreshInterval%3A(pause%3A!t%2Cvalue%3A0)%2Ctime%3A(from%3Anow-90d%2Cto%3Anow))" height="800" width="100%"></iframe>
              </EuiTitle>
            </EuiPageContentHeader>
           
          </EuiPageContent>
        </EuiPageBody>
      </EuiPage>
    );
  }
}
